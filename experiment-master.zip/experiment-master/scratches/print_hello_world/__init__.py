Var_name = 'Riley'
name = Var_name
hello_message = "Hi I am "+Var_name
print(hello_message)