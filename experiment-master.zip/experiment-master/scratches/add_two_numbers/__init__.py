Var_birthmonth = 12
Var_birthday = 30
print("birth month + birthday=")
print(Var_birthmonth+Var_birthday)