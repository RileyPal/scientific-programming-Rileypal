user_input: str = input("Celsius or Fahrenheit")
system: str = user_input
if system == "f" or "fahrenheit" or "F" or "Fahrenheit":
    return i=1
user_input: int = input("What temp")
n: int = user_input
ctof = (5/9)*n+32
ftoc = (9/5)*n+32
